from zpipz import utils

utils.check_cdk_version()
